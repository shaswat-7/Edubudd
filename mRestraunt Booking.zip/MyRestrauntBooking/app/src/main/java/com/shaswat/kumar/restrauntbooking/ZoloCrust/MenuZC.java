package com.shaswat.kumar.restrauntbooking.ZoloCrust;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.shaswat.kumar.restrauntbooking.R;

public class MenuZC extends AppCompatActivity {

    Toolbar menuZC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_zc);


        menuZC = findViewById(R.id.menuzc);


        setSupportActionBar(menuZC);
        getSupportActionBar().setTitle("MENU");
    }
}
