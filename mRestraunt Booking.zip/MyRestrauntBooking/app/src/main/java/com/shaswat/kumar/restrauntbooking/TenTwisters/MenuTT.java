package com.shaswat.kumar.restrauntbooking.TenTwisters;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.shaswat.kumar.restrauntbooking.R;

public class MenuTT extends AppCompatActivity {

    Toolbar menutt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_tt);


        menutt= findViewById(R.id.menutt);


        setSupportActionBar(menutt);
        getSupportActionBar().setTitle("MENU");
    }
}
