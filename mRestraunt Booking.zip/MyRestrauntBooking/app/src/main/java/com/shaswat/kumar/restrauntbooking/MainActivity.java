package com.shaswat.kumar.restrauntbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {



    private EditText mEmail_log;
    private EditText mPassWord_log;
    private Button mButton_login;
    private TextView mForgetPassword;
    private TextView mSignup_log;

    public ProgressDialog mDialog;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        mAuth = FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),RestaurantOpt.class));
        }

        mDialog = new ProgressDialog(this);

        loginFunction();


    }


    public void loginFunction(){

        mEmail_log = findViewById(R.id.login_email);
        mPassWord_log = findViewById(R.id.login_password);
        mButton_login = findViewById(R.id.login_button);
        mForgetPassword = findViewById(R.id.login_forgetPassword);
        mSignup_log =findViewById(R.id.login_singUp);

        mButton_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = mEmail_log.getText().toString().trim();
                String password = mPassWord_log.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    mEmail_log.setError("Required Field..");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    mPassWord_log.setError("Required Field..");
                    return;
                }

                mDialog.setMessage("Processing..");
                mDialog.show();


                mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {


                        if(task.isSuccessful()){
                            mDialog.dismiss();
                            startActivity(new Intent(getApplicationContext(),RestaurantOpt.class));
                            Toast.makeText(getApplicationContext(),"Login Complete..",Toast.LENGTH_SHORT).show();
                        } else{
                            mDialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Login Failed..",Toast.LENGTH_SHORT).show();
                        }

                    }
                });




            }
        });

        mSignup_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RegistrationActivity.class));
            }
        });

//        mForgetPassword.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),ResetActivity.class));
//            }
//        });

    }


}
